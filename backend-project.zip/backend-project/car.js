const express = require('express');
const router = express.Router();
const db = require('./db');

// GET /car - Get all cars
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM Car');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching cars:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// POST /car/add - Add a new car
router.post('/add', async (req, res) => {
  const { PlateNumber, DriverName, PhoneNumber, SlotNumber } = req.body;
  try {
    const [result] = await db.query(
      'INSERT INTO `Car`(`PlateNumber`, `DriverName`, `PhoneNumber`, `SlotNumber`) VALUES (?, ?, ?, ?)',
      [PlateNumber, DriverName, PhoneNumber, SlotNumber]
    );
    res.status(201).json({ PlateNumber, DriverName, PhoneNumber, SlotNumber });
  } catch (error) {
    console.error('Error adding car:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// GET /car/:PlateNumber - Get a car by PlateNumber
router.get('/:PlateNumber', async (req, res) => {
  const PlateNumber = req.params.PlateNumber;
  try {
    const [rows] = await db.query('SELECT * FROM Car WHERE PlateNumber = ?', [PlateNumber]);
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Car not found' });
    }
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching car:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;
