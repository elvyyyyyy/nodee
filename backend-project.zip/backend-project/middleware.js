function userVerify(req,res,next){
    if(req.session.user){
        next()
    }
    else{
        return res.send("T'es ou?")
    }
}
module.exports=userVerify