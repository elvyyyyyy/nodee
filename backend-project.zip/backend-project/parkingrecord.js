const express = require('express');
const router = express.Router();
const db = require('./db');

// GET /parkingrecord - Get all parking records
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM ParkingRecord');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching parking records:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// POST /parkingrecord/add - Add a new parking record
router.post('/add', async (req, res) => {
  const { EntryTime, ExitTime, Duration, SlotNumber } = req.body;
  try {
    const [result] = await db.query(
      'INSERT INTO `ParkingRecord`(`EntryTime`, `ExitTime`, `Duration`, `SlotNumber`) VALUES (?, ?, ?, ?)',
      [EntryTime, ExitTime, Duration, SlotNumber]
    );
    res.status(201).json({ EntryTime, ExitTime, Duration, SlotNumber });
  } catch (error) {
    console.error('Error adding parking record:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// PUT /parkingrecord/:id - Update a parking record by id
router.put('/:id', async (req, res) => {
  const id = req.params.id;
  const { EntryTime, ExitTime, Duration, SlotNumber } = req.body;
  try {
    const [result] = await db.query(
      'UPDATE `ParkingRecord` SET `EntryTime`=?, `ExitTime`=?, `Duration`=?, `SlotNumber`=? WHERE `RecordID`=?',
      [EntryTime, ExitTime, Duration, SlotNumber, id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Parking record not found' });
    }
    res.json({ id, EntryTime, ExitTime, Duration, SlotNumber });
  } catch (error) {
    console.error('Error updating parking record:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// GET /parkingrecord/:id - Get a parking record by id
router.get('/:id', async (req, res) => {
  const id = req.params.id;
  try {
    const [rows] = await db.query('SELECT * FROM ParkingRecord WHERE RecordID = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Parking record not found' });
    }
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching parking record:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// DELETE /parkingrecord/:id - Delete a parking record by id
router.delete('/:id', async (req, res) => {
  const id = req.params.id;
  try {
    const [result] = await db.query('DELETE FROM ParkingRecord WHERE RecordID = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Parking record not found' });
    }
    res.json({ message: 'Parking record deleted successfully' });
  } catch (error) {
    console.error('Error deleting parking record:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;
