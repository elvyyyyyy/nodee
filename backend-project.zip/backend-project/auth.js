const db = require('./db');
const userVerify = require('./middleware');
const bcrypt = require('bcryptjs');
const routes = require('express').Router();

function validateEmail(email) {
  const re = /^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/;
  return re.test(email);
}

function validatePassword(password) {
  const re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;
  return re.test(password);
}

routes.post('/signup', async function(req, res) {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ message: 'Name, email, and password are required' });
    }

    if (!validateEmail(email)) {
      return res.status(400).json({ message: 'Invalid email format' });
    }
    if (!validatePassword(password)) {
      return res.status(400).json({ message: 'Password must be minimum 8 characters, include uppercase, lowercase, number, and symbol' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    await db.query("INSERT INTO `user`(`name`, `email`, `password`) VALUES (?,?,?)", [name, email, hashedPassword]);
    res.json({ message: 'user created' });
  } catch (error) {
    console.error('Signup error:', error.stack || error);
    if (error.code === 'ER_DUP_ENTRY') {
      res.status(400).json({ message: 'Email already exists' });
    } else {
      res.status(500).json({ message: 'Internal server error', error: error.message });
    }
  }
});

routes.get('/test-db', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT 1 + 1 AS solution');
    res.json({ message: 'DB connection works', solution: rows[0].solution });
  } catch (error) {
    console.error('DB test error:', error.stack || error);
    res.status(500).json({ message: 'DB connection error', error: error.message });
  }
});

routes.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!validateEmail(email)) {
    return res.status(400).json({ message: 'Invalid email format' });
  }
  if (!validatePassword(password)) {
    return res.status(400).json({ message: 'Invalid password format' });
  }

  try {
    const [rows] = await db.query("SELECT * FROM `user` WHERE email=?", [email]);
    if (rows.length === 0) {
      return res.status(401).json({ message: "Invalid email or password" });
    }
    const user = rows[0];
    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      return res.status(401).json({ message: "Invalid email or password" });
    }
    req.session.user = user;
    return res.json({ message: "Logged in", user });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

routes.post('/logout', userVerify, async function(req, res) {
  req.session.destroy();
  return res.send('Logged out');
});

routes.get('/user', userVerify, async function(req, res) {
  return res.send({ user: req.session.user });
});

module.exports = routes;
