const express = require('express');
const app = express();
const expressSession = require('express-session');
const cors = require('cors');
const routes = require('./auth');
const productRoutes = require('./parkingslot');
const carRoutes = require('./car');
const parkingrecordRoutes = require('./parkingrecord');
const paymentRoutes = require('./payment');

const allowedOrigins = ['http://localhost:5173', 'http://localhost:5174', 'http://localhost:3000'];

app.use(cors({
    origin: function(origin, callback){
        if(!origin) return callback(null, true);
        if(allowedOrigins.indexOf(origin) === -1){
            const msg = 'The CORS policy for this site does not allow access from the specified Origin.';
            return callback(new Error(msg), false);
        }
        return callback(null, true);
    },
    credentials: true
}));
app.use(express.json());
app.use(expressSession({
    secret: 'asnous',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false,
        httpOnly: true,
        maxAge: 1000 * 60 * 60 * 24 // 1 day
    }
}));

app.use('/auth', routes);
app.use('/parkingslot', productRoutes);
app.use('/car', carRoutes);
app.use('/parkingrecord', parkingrecordRoutes);
app.use('/payment', paymentRoutes);

app.listen(3000, function () {
    console.log('Server running at 3000');
});
