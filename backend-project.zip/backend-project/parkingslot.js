const express = require('express');
const router = express.Router();
const db = require('./db');

// GET /parkingslot - Get all parking slots
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM ParkingSlot');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching parking slots:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// POST /parkingslot/add - Add a new parking slot
router.post('/add', async (req, res) => {
  const { SlotNumber, SlotStatus } = req.body;
  try {
    const [result] = await db.query(
      'INSERT INTO `ParkingSlot`(`SlotNumber`, `SlotStatus`) VALUES (?, ?)',
      [SlotNumber, SlotStatus]
    );
    res.status(201).json({ SlotNumber, SlotStatus });
  } catch (error) {
    console.error('Error adding parking slot:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// PUT /parkingslot/:SlotNumber - Update a parking slot by SlotNumber
router.put('/:SlotNumber', async (req, res) => {
  const SlotNumber = req.params.SlotNumber;
  const { SlotStatus } = req.body;
  try {
    const [result] = await db.query(
      'UPDATE `ParkingSlot` SET `SlotStatus`=? WHERE `SlotNumber`=?',
      [SlotStatus, SlotNumber]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Parking slot not found' });
    }
    res.json({ SlotNumber, SlotStatus });
  } catch (error) {
    console.error('Error updating parking slot:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// GET /parkingslot/:SlotNumber - Get a parking slot by SlotNumber
router.get('/:SlotNumber', async (req, res) => {
  const SlotNumber = req.params.SlotNumber;
  try {
    const [rows] = await db.query('SELECT * FROM ParkingSlot WHERE SlotNumber = ?', [SlotNumber]);
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Parking slot not found' });
    }
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching parking slot:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;
