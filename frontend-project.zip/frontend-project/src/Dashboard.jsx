import { Routes, Route, Navigate } from 'react-router-dom';
import AddParkingSlotForm from './AddParkingSlotForm';
import ParkingSlotsTable from './ParkingSlotsTable';
import EditParkingSlotForm from './EditParkingSlotForm';
import CarForm from './CarForm';
import CarTable from './CarTable';
import EditCarForm from './EditCarForm';
import ParkingRecordForm from './ParkingRecordForm';
import ParkingRecordTable from './ParkingRecordTable';
import EditParkingRecordForm from './EditParkingRecordForm';
import ParkingSlotsReport from './ParkingSlotsReport';
import DailyParkingPaymentReport from './DailyParkingPaymentReport';

function Dashboard() {
  return (
    <div className="min-h-screen p-20">
      <Routes>
        <Route path="/" element={<Navigate to="home" replace />} />
        <Route path="home" element={<ParkingSlotsTable />} />
        <Route path="addparkingslot" element={<AddParkingSlotForm />} />
        <Route path="editparkingslot/:slotNumber" element={<EditParkingSlotForm />} />
        <Route path="cars" element={<CarTable />} />
        <Route path="addcar" element={<CarForm />} />
        <Route path="editcar/:plateNumber" element={<EditCarForm />} />
        <Route path="parkingrecords" element={<ParkingRecordTable />} />
        <Route path="addparkingrecord" element={<ParkingRecordForm />} />
        <Route path="editparkingrecord/:id" element={<EditParkingRecordForm />} />
        <Route path="slotreport" element={<ParkingSlotsReport />} />
        <Route path="dailypaymentreport" element={<DailyParkingPaymentReport />} />
      </Routes>
    </div>
  );
}

export default Dashboard;
