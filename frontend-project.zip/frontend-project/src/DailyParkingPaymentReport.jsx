import React, { useState, useEffect } from 'react';
import axios from 'axios';

function DailyParkingPaymentReport() {
  const [payments, setPayments] = useState([]);
  const [parkingRecords, setParkingRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Helper function to format date/time
  const formatDateTime = (dateTimeStr) => {
    const date = new Date(dateTimeStr);
    return date.toLocaleString();
  };

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        const [paymentsRes, recordsRes] = await Promise.all([
          axios.get('http://localhost:3000/payment'),
          axios.get('http://localhost:3000/parkingrecord'),
        ]);
        setPayments(paymentsRes.data);
        setParkingRecords(recordsRes.data);
        setLoading(false);
      } catch (err) {
        setError('Failed to fetch report data');
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <div className="min-h-screen p-6 flex justify-center items-center">Loading report...</div>;
  }

  if (error) {
    return <div className="min-h-screen p-6 flex justify-center items-center text-red-600">{error}</div>;
  }

  // Filter payments for today only
  const today = new Date();
  const isSameDay = (date1, date2) =>
    date1.getFullYear() === date2.getFullYear() &&
    date1.getMonth() === date2.getMonth() &&
    date1.getDate() === date2.getDate();

  const todaysPayments = payments.filter(payment => {
    const paymentDate = new Date(payment.PaymentDate);
    return isSameDay(paymentDate, today);
  });

  // Join payments with parking records by SlotNumber
  const reportData = todaysPayments.map(payment => {
    const record = parkingRecords.find(r => r.SlotNumber === payment.SlotNumber);
    return {
      plateName: record ? record.PlateName : 'Unknown',
      entryTime: record ? record.EntryTime : 'Unknown',
      duration: record ? record.Duration : 'Unknown',
      amountPaid: payment.AmountPaid,
    };
  });

  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold mb-4 text-green-800">Daily Parking Payment Report</h2>
      <table className="min-w-full bg-white border border-gray-300 rounded">
        <thead>
          <tr>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">#</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">Plate Name</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">Entry Time</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">Duration</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">Amount Paid</th>
          </tr>
        </thead>
        <tbody>
          {reportData.map((item, index) => (
            <tr key={index} className="hover:bg-gray-100 even:bg-green-100">
              <td className="py-2 px-4 border-b border-gray-300">{index + 1}</td>
              <td className="py-2 px-4 border-b border-gray-300">{item.plateName}</td>
              <td className="py-2 px-4 border-b border-gray-300">{formatDateTime(item.entryTime)}</td>
              <td className="py-2 px-4 border-b border-gray-300">{item.duration}</td>
              <td className="py-2 px-4 border-b border-gray-300">{item.amountPaid}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default DailyParkingPaymentReport;
