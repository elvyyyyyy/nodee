import { useState, useEffect } from 'react';
import axios from 'axios';

function ParkingSlotsTable() {
  const [parkingSlots, setParkingSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchParkingSlots = async () => {
    try {
      const response = await axios.get('http://localhost:3000/parkingslot');
      setParkingSlots(response.data);
      setLoading(false);
    } catch {
      setError('Failed to fetch parking slots');
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchParkingSlots();
  }, []);

  if (loading) {
    return <div className="min-h-screen p-6 flex justify-center items-center">Loading parking slots...</div>;
  }

  if (error) {
    return <div className="min-h-screen p-6 flex justify-center items-center text-red-600">{error}</div>;
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4 text-green-800">Parking Slots</h2>
      <table className="min-w-full bg-white border border-gray-300 rounded">
        <thead>
          <tr>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">#</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">Slot Number</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">Slot Status</th>
          </tr>
        </thead>
        <tbody>
          {parkingSlots.map((slot, index) => (
            <tr key={slot.SlotNumber} className="hover:bg-gray-100 even:bg-green-100">
              <td className="py-2 px-4 border-b border-gray-300">{index + 1}</td>
              <td className="py-2 px-4 border-b border-gray-300">{slot.SlotNumber}</td>
              <td className="py-2 px-4 border-b border-gray-300">{slot.SlotStatus}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ParkingSlotsTable;
