import { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate, useLocation, Navigate } from 'react-router-dom';
import Login from './Login';
import Register from './Register';
import Dashboard from './Dashboard';
import MainPage from './MainPage.jsx';
import './App.css';

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

function AppContent() {
  const [user, setUser] = useState({ id: 1, name: 'Test User' });
  const location = useLocation();

  return (
    <>
      {location.pathname !== '/' && location.pathname !== '/login' && location.pathname !== '/register' && (
        <NavBar user={user} setUser={setUser} />
      )}
      <main className="flex-grow container mx-auto p-6 mt-5">
        <Routes>
          <Route path="/" element={<MainPage />} />
          <Route path="/login" element={<Login setUser={setUser} />} />
          <Route path="/register" element={<Register setUser={setUser} />} />
          <Route path="/dashboard/*" element={<Dashboard />} />
        </Routes>
      </main>
    </>
  );
}

function NavBar({ user, setUser }) {
  const navigate = useNavigate();
  const location = useLocation();
  const tabs = ['home','addparkingslot', 'addcar', 'addparkingrecord','dailypaymentreport' ,'slotreport'];

  // Determine active tab based on current path
  let activeTab = '';
  if (location.pathname.startsWith('/dashboard')) {
    const pathTab = location.pathname.split('/')[2];
    activeTab = pathTab ? pathTab.toLowerCase() : 'home';
  }

const handleLogout = () => {
  setUser(null);
  navigate('/');
};


  return (
    <nav className="fixed top-0 left-0 bottom-0 w-60 bg-green-800 p-5 text-white z-50 flex flex-col justify-between ">
      <div className="flex flex-col space-y-4">
        {user &&
          tabs.map((tab) => (
            <Link
              key={tab}
              to={`/dashboard/${tab.replace(/\s+/g, '')}`}
              className={`capitalize px-3 py-2 rounded ${
                activeTab === tab.replace(/\s+/g, '').toLowerCase()
                  ? 'bg-green-50 text-black font-medium'
                  : 'text-white hover:bg-green-50 hover:text-black'
              }`}
            >
              {tab}
            </Link>
          ))}
      </div>
      <div className="flex flex-col space-y-4">
        {!user ? (
          <>
            <Link to="/login" className="bg-white text-green-800 px-3 py-2 rounded hover:bg-gray-200">
              Login
            </Link>
            <Link to="/register" className="bg-white text-green-800 px-3 py-2 rounded hover:bg-gray-200">
              Register
            </Link>
          </>
        ) : (
          <button
            onClick={handleLogout}
            className="bg-green-50 text-green-800 px-3 py-2 rounded hover:bg-green-100"
          >
            Logout
          </button>
        )}
      </div>
    </nav>
  );
}

export default App;
