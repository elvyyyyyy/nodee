import { Link } from 'react-router-dom';

function MainPage() {
  return (
    <div className="flex flex-col justify-center items-center mt-50">
      <h1 className="text-4xl font-bold mb-6 text-green-800">Welcome to the Parking System</h1>
      <div className="space-x-4">
        <Link
          to="/login"
          className="bg-green-800 text-white px-6 py-3 rounded hover:bg-green-700 transition-colors"
        >
          Login
        </Link>
        <Link
          to="/register"
          className="bg-green-800 text-white px-6 py-3 rounded hover:bg-green-700 transition-colors"
        >
          Register
        </Link>
      </div>
    </div>
  );
}

export default MainPage;
