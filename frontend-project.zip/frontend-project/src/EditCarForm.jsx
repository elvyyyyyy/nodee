import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

function EditCarForm() {
  const { plateNumber } = useParams();
  const navigate = useNavigate();

  const [driverName, setDriverName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [slotNumber, setSlotNumber] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCar = async () => {
      try {
        const response = await axios.get(`http://localhost:3000/car/${plateNumber}`);
        const car = response.data;
        setDriverName(car.DriverName);
        setPhoneNumber(car.PhoneNumber);
        setSlotNumber(car.SlotNumber);
        setLoading(false);
      } catch {
        setError('Failed to fetch car data');
        setLoading(false);
      }
    };
    fetchCar();
  }, [plateNumber]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!driverName || !phoneNumber || !slotNumber) {
      setMessage('Please fill all required fields');
      return;
    }
    try {
      await axios.put(`http://localhost:3000/car/${plateNumber}`, {
        DriverName: driverName,
        PhoneNumber: phoneNumber,
        SlotNumber: Number(slotNumber),
      });
      setMessage('Car updated successfully');
      navigate('/dashboard/cars');
    } catch {
      setMessage('Failed to update car');
    }
  };

  if (loading) {
    return <div className="p-6 flex justify-center items-center">Loading car data...</div>;
  }

  if (error) {
    return <div className="p-6 text-red-600">{error}</div>;
  }

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded shadow-md">
      <h2 className="text-2xl font-semibold mb-6 text-rose-950">Edit Car</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Driver Name</label>
          <input
            type="text"
            value={driverName}
            onChange={(e) => setDriverName(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          />
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Phone Number</label>
          <input
            type="text"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          />
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Slot Number</label>
          <input
            type="number"
            value={slotNumber}
            onChange={(e) => setSlotNumber(e.target.value)}
            required
            min="0"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          />
        </div>
        <button
          type="submit"
          className="w-full bg-rose-950 text-white py-2 rounded-md hover:bg-pink-950 transition-colors"
        >
          Update Car
        </button>
      </form>
      {message && <p className="mt-4 text-center text-green-600">{message}</p>}
    </div>
  );
}

export default EditCarForm;
