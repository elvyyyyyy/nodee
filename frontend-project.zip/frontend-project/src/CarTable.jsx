import { useState, useEffect } from 'react';
import axios from 'axios';

function CarTable() {
  const [cars, setCars] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchCars = async () => {
    try {
      const response = await axios.get('http://localhost:3000/car');
      setCars(response.data);
      setLoading(false);
    } catch {
      setError('Failed to fetch cars');
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCars();
  }, []);

  if (loading) {
    return <div className="min-h-screen p-6 flex justify-center items-center">Loading cars...</div>;
  }

  if (error) {
    return <div className="min-h-screen p-6 flex justify-center items-center text-red-600">{error}</div>;
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4 text-green-800">Cars</h2>
      <table className="min-w-full bg-white border border-gray-300 rounded">
        <thead>
          <tr>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">#</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">Plate Number</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">Driver Name</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">Phone Number</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">Slot Number</th>
          </tr>
        </thead>
        <tbody>
          {cars.map((car, index) => (
            <tr key={car.PlateNumber} className="hover:bg-gray-100 even:bg-green-100">
              <td className="py-2 px-4 border-b border-gray-300">{index + 1}</td>
              <td className="py-2 px-4 border-b border-gray-300">{car.PlateNumber}</td>
              <td className="py-2 px-4 border-b border-gray-300">{car.DriverName}</td>
              <td className="py-2 px-4 border-b border-gray-300">{car.PhoneNumber}</td>
              <td className="py-2 px-4 border-b border-gray-300">{car.SlotNumber}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default CarTable;
