import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

function EditParkingRecordForm() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [entryTime, setEntryTime] = useState('');
  const [exitTime, setExitTime] = useState('');
  const [duration, setDuration] = useState('');
  const [slotNumber, setSlotNumber] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchParkingRecord = async () => {
      try {
        const response = await axios.get(`http://localhost:3000/parkingrecord/${id}`);
        const record = response.data;
        setEntryTime(record.EntryTime);
        setExitTime(record.ExitTime);
        setDuration(record.Duration);
        setSlotNumber(record.SlotNumber);
        setLoading(false);
      } catch {
        setError('Failed to fetch parking record data');
        setLoading(false);
      }
    };
    fetchParkingRecord();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!entryTime || !exitTime || !duration || !slotNumber) {
      setMessage('Please fill all required fields');
      return;
    }
    try {
      await axios.put(`http://localhost:3000/parkingrecord/${id}`, {
        EntryTime: entryTime,
        ExitTime: exitTime,
        Duration: Number(duration),
        SlotNumber: Number(slotNumber),
      });
      setMessage('Parking record updated successfully');
      navigate('/dashboard/parkingrecords');
    } catch {
      setMessage('Failed to update parking record');
    }
  };

  if (loading) {
    return <div className="p-6 flex justify-center items-center">Loading parking record data...</div>;
  }

  if (error) {
    return <div className="p-6 text-red-600">{error}</div>;
  }

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded shadow-md">
      <h2 className="text-2xl font-semibold mb-6 text-green-800">Edit Parking Record</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Entry Time</label>
          <input
            type="datetime-local"
            value={entryTime}
            onChange={(e) => setEntryTime(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-800"
          />
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Exit Time</label>
          <input
            type="datetime-local"
            value={exitTime}
            onChange={(e) => setExitTime(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-800"
          />
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Duration (minutes)</label>
          <input
            type="number"
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
            required
            min="0"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-800"
          />
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Slot Number</label>
          <input
            type="number"
            value={slotNumber}
            onChange={(e) => setSlotNumber(e.target.value)}
            required
            min="0"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-800"
          />
        </div>
        <button
          type="submit"
          className="w-full bg-green-800 text-white py-2 rounded-md hover:bg-green-700 transition-colors"
        >
          Update Parking Record
        </button>
      </form>
      {message && <p className="mt-4 text-center text-green-600">{message}</p>}
    </div>
  );
}

export default EditParkingRecordForm;
