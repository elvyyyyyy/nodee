import { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function ParkingRecordTable() {
  const [parkingRecords, setParkingRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const fetchParkingRecords = async () => {
    try {
      const response = await axios.get('http://localhost:3000/parkingrecord');
      setParkingRecords(response.data);
      setLoading(false);
    } catch {
      setError('Failed to fetch parking records');
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchParkingRecords();
  }, []);

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:3000/parkingrecord/${id}`);
      setParkingRecords(parkingRecords.filter(record => record.RecordID !== id));
    } catch {
      setError('Failed to delete parking record');
    }
  };

  if (loading) {
    return <div className="min-h-screen p-6 flex justify-center items-center">Loading parking records...</div>;
  }

  if (error) {
    return <div className="min-h-screen p-6 flex justify-center items-center text-red-600">{error}</div>;
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4 text-rose-950">Parking Records</h2>
      <table className="min-w-full bg-white border border-gray-300 rounded">
        <thead>
          <tr>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">#</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">Entry Time</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">Exit Time</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">Duration</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">Slot Number</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">Actions</th>
          </tr>
        </thead>
        <tbody>
          {parkingRecords.map((record, index) => (
            <tr key={record.RecordID} className="hover:bg-gray-100 even:bg-rose-100">
              <td className="py-2 px-4 border-b border-gray-300">{index + 1}</td>
              <td className="py-2 px-4 border-b border-gray-300">{record.EntryTime}</td>
              <td className="py-2 px-4 border-b border-gray-300">{record.ExitTime}</td>
              <td className="py-2 px-4 border-b border-gray-300">{record.Duration}</td>
              <td className="py-2 px-4 border-b border-gray-300">{record.SlotNumber}</td>
              <td className="py-2 px-4 border-b border-gray-300">
                <div className="flex space-x-2 items-center justify-center">
                  <button
                    onClick={() => navigate(`/dashboard/edit-parkingrecord/${record.RecordID}`)}
                    className="bg-rose-950 text-white px-4 py-1 mr-5 rounded hover:bg-rose-600"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(record.RecordID)}
                    className="bg-red-800 text-white px-3 py-1 rounded hover:bg-red-600"
                  >
                    Delete
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ParkingRecordTable;
