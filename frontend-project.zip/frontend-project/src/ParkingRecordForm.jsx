import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function ParkingRecordForm() {
  const [entryTime, setEntryTime] = useState('');
  const [exitTime, setExitTime] = useState('');
  const [duration, setDuration] = useState('');
  const [slotNumber, setSlotNumber] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!entryTime || !exitTime || !duration || !slotNumber) {
      setMessage('Please fill all required fields');
      return;
    }
    try {
      const parkingRecordData = {
        EntryTime: entryTime,
        ExitTime: exitTime,
        Duration: Number(duration),
        SlotNumber: Number(slotNumber),
      };
      await axios.post('http://localhost:3000/parkingrecord/add', parkingRecordData, { withCredentials: true });
      setMessage('Parking record added successfully');
      // Reset form
      setEntryTime('');
      setExitTime('');
      setDuration('');
      setSlotNumber('');
      // Redirect to parkingrecord table page
      navigate('/dashboard/parkingrecords');
    } catch (error) {
      console.error('Failed to submit parking record:', error);
      setMessage('Failed to submit parking record');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded shadow-md">
      <h2 className="text-2xl font-semibold mb-6 text-green-800">Add Parking Record</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Entry Time</label>
          <input
            type="datetime-local"
            value={entryTime}
            onChange={(e) => setEntryTime(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-800"
          />
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Exit Time</label>
          <input
            type="datetime-local"
            value={exitTime}
            onChange={(e) => setExitTime(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-800"
          />
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Duration (minutes)</label>
          <input
            type="number"
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
            required
            min="0"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-800"
          />
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Slot Number</label>
          <input
            type="number"
            value={slotNumber}
            onChange={(e) => setSlotNumber(e.target.value)}
            required
            min="0"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-800"
          />
        </div>
        <button
          type="submit"
          className="w-full bg-green-800 text-white py-2 rounded-md hover:bg-green-700 transition-colors"
        >
          Submit Parking Record
        </button>
      </form>
      {message && <p className="mt-4 text-center text-green-600">{message}</p>}
    </div>
  );
}

export default ParkingRecordForm;
