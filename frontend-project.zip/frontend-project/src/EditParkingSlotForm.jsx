import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

function EditParkingSlotForm() {
  const { slotNumber } = useParams();
  const navigate = useNavigate();

  const [slotStatus, setSlotStatus] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchParkingSlot = async () => {
      try {
        const response = await axios.get(`http://localhost:3000/parkingslot/${slotNumber}`);
        const parkingSlot = response.data;
        setSlotStatus(parkingSlot.SlotStatus);
        setLoading(false);
      } catch {
        setError('Failed to fetch parking slot data');
        setLoading(false);
      }
    };

    fetchParkingSlot();
  }, [slotNumber]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:3000/parkingslot/${slotNumber}`, {
        SlotStatus: slotStatus,
      });
      navigate('/dashboard/home');
    } catch  {
      setError('Failed to update parking slot');
    }
  };

  if (loading) {
    return <div className="p-6 flex justify-center items-center">Loading parking slot data...</div>;
  }

  if (error) {
    return <div className="p-6 text-red-600">{error}</div>;
  }

  return (
    <div className="max-w-md mx-auto mt-20 p-6 rounded-lg shadow-md bg-white">
      <h2 className="text-2xl font-semibold mb-6 text-green-800">Edit Parking Slot</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Slot Status:</label>
          <input
            type="text"
            value={slotStatus}
            onChange={(e) => setSlotStatus(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-800"
          />
        </div>
        <button
          type="submit"
          className="w-full bg-green-800 text-white py-2 rounded-md hover:bg-green-700 transition-colors"
        >
          Save Changes
        </button>
      </form>
    </div>
  );
}

export default EditParkingSlotForm;
