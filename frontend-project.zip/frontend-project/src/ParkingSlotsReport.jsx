import React, { useState, useEffect } from 'react';
import axios from 'axios';

function ParkingSlotsReport() {
  const [parkingSlots, setParkingSlots] = useState([]);
  const [parkingRecords, setParkingRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedSlot, setSelectedSlot] = useState('all');

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [slotsRes, recordsRes] = await Promise.all([
        axios.get('http://localhost:3000/parkingslot'),
        axios.get('http://localhost:3000/parkingrecord'),
      ]);
      setParkingSlots(slotsRes.data);
      setParkingRecords(recordsRes.data);
      setLoading(false);
    } catch {
      setError('Failed to fetch report data');
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  if (loading) {
    return <div className="min-h-screen p-6 flex justify-center items-center">Loading report...</div>;
  }

  if (error) {
    return <div className="min-h-screen p-6 flex justify-center items-center text-red-600">{error}</div>;
  }

  // Aggregate total duration by slot number
  const durationMap = {};
  parkingRecords.forEach(record => {
    const slotNumber = record.SlotNumber || 'Unknown';
    if (!durationMap[slotNumber]) {
      durationMap[slotNumber] = 0;
    }
    durationMap[slotNumber] += record.Duration || 0;
  });

  // Prepare report data
  const reportData = parkingSlots.map(slot => {
    const totalDuration = durationMap[slot.SlotNumber] || 0;
    return {
      slotNumber: slot.SlotNumber,
      slotStatus: slot.SlotStatus,
      totalDuration,
    };
  });

  // Filter report data based on selected slot
  const filteredReportData = selectedSlot === 'all'
    ? reportData
    : reportData.filter(item => item.slotNumber === Number(selectedSlot));

  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold mb-4 text-green-800">Parking Slots Usage Report</h2>
      <div className="mb-4">
        <label htmlFor="slotSelect" className="mr-2 font-medium">Select Parking Slot:</label>
        <select
          id="slotSelect"
          value={selectedSlot}
          onChange={e => setSelectedSlot(e.target.value)}
          className="border border-gray-300 rounded px-2 py-1"
        >
          <option value="all">All</option>
          {reportData.map(item => (
            <option key={item.slotNumber} value={item.slotNumber}>{item.slotNumber}</option>
          ))}
        </select>
      </div>
      <table className="min-w-full bg-white border border-gray-300 rounded">
        <thead>
          <tr>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">#</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">Slot Number</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">Slot Status</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-green-800 text-white">Total Duration</th>
          </tr>
        </thead>
        <tbody>
          {filteredReportData.map((item, index) => (
            <tr key={item.slotNumber} className="hover:bg-gray-100 even:bg-green-100">
              <td className="py-2 px-4 border-b border-gray-300">{index + 1}</td>
              <td className="py-2 px-4 border-b border-gray-300">{item.slotNumber}</td>
              <td className="py-2 px-4 border-b border-gray-300">{item.slotStatus}</td>
              <td className="py-2 px-4 border-b border-gray-300">{item.totalDuration}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ParkingSlotsReport;
