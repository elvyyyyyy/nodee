import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function AddParkingSlotForm() {
  const [slotNumber, setSlotNumber] = useState('');
  const [slotStatus, setSlotStatus] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:3000/parkingslot/add', {
        SlotNumber: Number(slotNumber),
        SlotStatus: slotStatus,
      }, { withCredentials: true });

      setMessage(response.data.message || 'Parking slot added successfully');
      setSlotNumber('');
      setSlotStatus('');
      navigate('/dashboard/home');
    } catch {
      setMessage('Failed to add parking slot');
    }
  };

  return (
    <div className='justify-center items-center'>

      <form onSubmit={handleSubmit} className="w-100 bg-white p-7 rounded shadow-md mt-5 ml-90">
        <h2 className="text-xl font-semibold mb-4 text-green-800">Add Parking Slot</h2>
        <div className="mb-4">
          <label className="block mb-1 font-medium text-gray-700 text-left">Slot Number</label>
          <input
            type="number"
            value={slotNumber}
            onChange={(e) => setSlotNumber(e.target.value)}
            required
            min="0"
            className="w-full border border-gray-300 rounded px-3 py-2"
          />
        </div>
        <div className="mb-4">
          <label className="block mb-1 font-medium text-gray-700 text-left">Slot Status</label>
          <input
            type="text"
            value={slotStatus}
            onChange={(e) => setSlotStatus(e.target.value)}
            required
            className="w-full border border-gray-300 rounded px-3 py-2"
          />
        </div>
        <button
          type="submit"
          className="w-full bg-green-800 text-white px-4 py-2 rounded hover:bg-green-700 transition-colors"
        >
          Submit
        </button>
        {message && <p className="mt-4 text-green-600">{message}</p>}
      </form>
    </div>
  );
}

export default AddParkingSlotForm;
