const express = require('express');
const router = express.Router();
const db = require('./db');

// POST /imports - Add a new import record
router.post('/', async (req, res) => {
  const { pro_name, product_id, address, date, pro_quantity } = req.body;
  if (!pro_name || !product_id || !address || !date || !pro_quantity) {
    return res.status(400).json({ message: 'Missing required fields' });
  }
  try {
    const [result] = await db.query(
      'INSERT INTO imports (pro_name, product_id, address, date, pro_quantity) VALUES (?, ?, ?, ?, ?)',
      [pro_name, product_id, address, date, pro_quantity]
    );
    res.status(201).json({ id: result.insertId, pro_name, address, date, pro_quantity });
  } catch (error) {
    console.error('Error adding import:', error);
    res.status(500).json({ message: error.message || 'Internal server error' });
  }
});

// GET /imports - Get all import records
  router.get('/', async (req, res) => {
    try {
      const [rows] = await db.query(
        `SELECT imports.id, imports.product_id, products.pro_name, imports.address, imports.date, imports.pro_quantity
         FROM imports
         JOIN products ON imports.product_id = products.id`
      );
      res.json(rows);
    } catch (error) {
      console.error('Error fetching imports:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

// GET /imports/:id - Get a single import record by id
router.get('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const [rows] = await db.query(
      `SELECT imports.id, imports.product_id, products.pro_name, imports.address, imports.date, imports.pro_quantity
       FROM imports
       JOIN products ON imports.product_id = products.id
       WHERE imports.id = ?`,
      [id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Import record not found' });
    }
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching import:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { pro_name, product_id, address, date, pro_quantity } = req.body;
  if (!pro_name || !product_id || !address || !date || !pro_quantity) {
    return res.status(400).json({ message: 'Missing required fields' });
  }
  try {
    const [result] = await db.query(
      'UPDATE imports SET pro_name = ?, product_id = ?, address = ?, date = ?, pro_quantity = ? WHERE id = ?',
      [pro_name, product_id, address, date, pro_quantity, id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Import record not found' });
    }
    res.json({ id, pro_name, product_id, address, date, pro_quantity });
  } catch (error) {
    console.error('Error updating import:', error);
    res.status(500).json({ message: error.message || 'Internal server error' });
  }
});

// DELETE /imports/:id - Delete an import record
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const [result] = await db.query('DELETE FROM imports WHERE id = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Import record not found' });
    }
    res.json({ message: 'Import record deleted successfully' });
  } catch (error) {
    console.error('Error deleting import:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;
