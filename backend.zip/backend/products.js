const express = require('express');
const router = express.Router();
const db = require('./db');

// GET /products - Get all products
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM products');
    res.json(rows);
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// POST /products - Add a new product
router.post('/add', async (req, res) => {
  const { pro_name, pro_owner, pro_quantity } = req.body;
  try {
    const [result] = await db.query(
      'INSERT INTO `products`( `pro_name`, `pro_owner`, `pro_quantity`) VALUES (?,?,?)',
      [pro_name, pro_owner, pro_quantity]
    );
    res.status(201).json({ id: result.insertId, pro_name, pro_owner, pro_quantity });
  } catch (error) {
    console.error('Error adding product:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// PUT /products/:id - Update a product by id
router.put('/:id', async (req, res) => {
  const productId = req.params.id;
  const { pro_name, pro_owner, pro_quantity } = req.body;
  try {
    const [result] = await db.query(
      'UPDATE `products` SET `pro_name`=?,`pro_owner`=?,`pro_quantity`=? WHERE  `id`=?',
      [pro_name, pro_owner, pro_quantity, productId]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Product not found' });
    }
    res.json({ id: productId, pro_name, pro_owner, pro_quantity });
  } catch (error) {
    console.error('Error updating product:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// GET /products/:id - Get a product by id
router.get('/:id', async (req, res) => {
  const productId = req.params.id;
  try {
    const [rows] = await db.query('SELECT * FROM products WHERE id = ?', [productId]);
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Product not found' });
    }
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching product:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});


// DELETE /products/:id - Delete a product by id
router.delete('/:id', async (req, res) => {
  const productId = req.params.id;
  try {
    const [result] = await db.query('DELETE FROM products WHERE id = ?', [productId]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Product not found' });
    }
    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Error deleting product:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;
