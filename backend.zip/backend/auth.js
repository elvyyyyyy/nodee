const db = require('./db');
const userVerify = require('./middleware');
const routes = require('express').Router();

routes.post('/signup', async function(req, res) {
  const { name, email, password } = req.body;
  try {
    await db.query("INSERT INTO `user`(`name`, `email`, `password`) VALUES (?,?,?)", [name, email, password]);
    res.json({ message: 'user created' });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      res.status(400).json({ message: 'Email already exists' });
    } else {
      res.status(500).json({ message: 'Internal server error' });
    }
  }
});

routes.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    console.log('Login attempt:', email, password);
    const [rows] = await db.query("SELECT * FROM `user` WHERE email=? AND password=?", [email, password]);
    console.log('Login query result:', rows);
    if (rows.length > 0) {
      req.session.user = rows[0];
      return res.json({ message: "Logged in", user: rows[0] });
    } else {
      return res.status(401).json({ message: "Invalid email or password" });
    }
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

routes.post('/logout', userVerify, async function(req, res) {
  req.session.destroy();
  return res.send('Logged out');
});

routes.get('/user', userVerify, async function(req, res) {
  return res.send({ user: req.session.user });
});

module.exports = routes;
