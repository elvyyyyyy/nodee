const express = require('express');
const router = express.Router();
const db = require('./db');

// POST /exports - Add a new export record
  router.post('/', async (req, res) => {
    const { pro_name, product_id, address, date, pro_quantity } = req.body;
    if (!pro_name || !product_id || !address || !date || !pro_quantity) {
      return res.status(400).json({ message: 'Missing required fields' });
    }
    try {
      const [result] = await db.query(
        'INSERT INTO exports (pro_name, product_id, address, date, pro_quantity) VALUES (?, ?, ?, ?, ?)',
        [pro_name, product_id, address, date, pro_quantity]
      );
      res.status(201).json({ id: result.insertId, pro_name, address, date, pro_quantity });
  } catch (error) {
    console.error('Error adding export:', error);
    res.status(500).json({ message: error.message || 'Internal server error' });
  }
  });

// GET /exports - Get all export records
  router.get('/', async (req, res) => {
    try {
      const [rows] = await db.query(
        `SELECT exports.id, exports.product_id, products.pro_name, exports.address, exports.date, exports.pro_quantity
         FROM exports
         JOIN products ON exports.product_id = products.id`
      );
      res.json(rows);
    } catch (error) {
      console.error('Error fetching exports:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
// GET /exports/:id - Get a single export record by id
router.get('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const [rows] = await db.query(
      `SELECT exports.id, exports.product_id, products.pro_name, exports.address, exports.date, exports.pro_quantity
       FROM exports
       JOIN products ON exports.product_id = products.id
       WHERE exports.id = ?`,
      [id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Export record not found' });
    }
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching export:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { pro_name, product_id, address, date, pro_quantity } = req.body;
  if (!pro_name || !product_id || !address || !date || !pro_quantity) {
    return res.status(400).json({ message: 'Missing required fields' });
  }
  try {
    const [result] = await db.query(
      'UPDATE exports SET pro_name = ?, product_id = ?, address = ?, date = ?, pro_quantity = ? WHERE id = ?',
      [pro_name, product_id, address, date, pro_quantity, id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Export record not found' });
    }
    res.json({ id, pro_name, product_id, address, date, pro_quantity });
  } catch (error) {
    console.error('Error updating export:', error);
    res.status(500).json({ message: error.message || 'Internal server error' });
  }
});

// DELETE /exports/:id - Delete an export record
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const [result] = await db.query('DELETE FROM exports WHERE id = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Export record not found' });
    }
    res.json({ message: 'Export record deleted successfully' });
  } catch (error) {
    console.error('Error deleting export:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;
