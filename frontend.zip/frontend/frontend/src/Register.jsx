import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Register({ setUser }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:3000/auth/signup', { name, email, password });
      setMessage(response.data);
      if (response.data === 'user created') {
        setUser({ name, email }); // Set user state after registration
        navigate('/dashboard');
      }
    } catch (error) {
      setMessage('Registration failed');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-20 p-6  rounded-lg shadow-md">
      <h2 className="text-2xl font-semibold mb-6 text-rose-950">Register</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1 text-rose-950 text-left font-medium">Name:</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          />
        </div>
        <div>
          <label className="block mb-1 text-rose-950 text-left font-medium">Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          />
        </div>
        <div>
          <label className="block mb-1 text-rose-950 text-left font-medium">Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          />
        </div>
        <button
          type="submit"
          className="w-full bg-rose-950 text-white py-2 rounded-md hover:bg-pink-950 transition-colors"
        >
          Register
        </button>
      </form>
      {message && <p className="mt-4 text-center text-rose-950">{message}</p>}
    </div>
  );
}

export default Register;
