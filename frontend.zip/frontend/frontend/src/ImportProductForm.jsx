import { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function ImportProductForm() {
  const [products, setProducts] = useState([]);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [address, setAddress] = useState('');
  const [date, setDate] = useState('');
  const [proQuantity, setProQuantity] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get('http://localhost:3000/products');
        setProducts(response.data);
      } catch (error) {
        console.error('Failed to fetch products:', error);
      }
    };
    fetchProducts();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedProductId) {
      setMessage('Please select a product');
      return;
    }
    if (!address || !date || !proQuantity) {
      setMessage('Please fill all fields');
      return;
    }
    try {
      const selectedProduct = products.find(p => p.id === Number(selectedProductId));
      const importData = {
        pro_name: selectedProduct ? selectedProduct.pro_name : '',
        product_id: Number(selectedProductId),
        address,
        date,
        pro_quantity: Number(proQuantity),
      };
      await axios.post('http://localhost:3000/imports/', importData, { withCredentials: true });
      setMessage('Import submitted successfully');
      // Reset form
      setSelectedProductId('');
      setAddress('');
      setDate('');
      setProQuantity('');
      // Redirect to imports table page
      navigate('/dashboard/imports');
    } catch (error) {
      console.error('Failed to submit import:', error);
      setMessage('Failed to submit import');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded shadow-md">
      <h2 className="text-2xl font-semibold mb-6 text-rose-950">Import Product</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Product</label>
          <select
            value={selectedProductId}
            onChange={(e) => setSelectedProductId(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          >
            <option value="">Select a product</option>
            {products.map((product) => (
              <option key={product.id} value={product.id}>
                {product.pro_name} (ID: {product.id})
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Destination Address</label>
          <input
            type="text"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          />
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Import Date</label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          />
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Quantity</label>
          <input
            type="number"
            value={proQuantity}
            onChange={(e) => setProQuantity(e.target.value)}
            required
            min="1"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          />
        </div>
        <button
          type="submit"
          className="w-full bg-rose-950 text-white py-2 rounded-md hover:bg-pink-950 transition-colors"
        >
          Submit Import
        </button>
      </form>
      {message && <p className="mt-4 text-center text-green-600">{message}</p>}
    </div>
  );
}

export default ImportProductForm;
