import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

function EditProductForm() {
  const { productId } = useParams();
  const navigate = useNavigate();

  const [productName, setProductName] = useState('');
  const [productOwner, setProductOwner] = useState('');
  const [productQuantity, setProductQuantity] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await axios.get(`http://localhost:3000/products/${productId}`);
        const product = response.data;
        setProductName(product.pro_name);
        setProductOwner(product.pro_owner);
        setProductQuantity(product.pro_quantity);
        setLoading(false);
      } catch (err) {
        setError('Failed to fetch product data');
        setLoading(false);
      }
    };

    fetchProduct();
  }, [productId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:3000/products/${productId}`, {
        pro_name: productName,
        pro_owner: productOwner,
        pro_quantity: Number(productQuantity),
      });
      navigate('/dashboard/home');
    } catch (err) {
      setError('Failed to update product');
    }
  };

  if (loading) {
    return <div className="p-6 flex justify-center items-center">Loading product data...</div>;
  }

  if (error) {
    return <div className="p-6 text-red-600">{error}</div>;
  }

  return (
    <div className="max-w-md mx-auto mt-20 p-6 rounded-lg shadow-md bg-white">
      <h2 className="text-2xl font-semibold mb-6 text-rose-950">Edit Product</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Product Name:</label>
          <input
            type="text"
            value={productName}
            onChange={(e) => setProductName(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          />
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Product Owner:</label>
          <input
            type="text"
            value={productOwner}
            onChange={(e) => setProductOwner(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          />
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900 text-left">Product Quantity:</label>
          <input
            type="number"
            value={productQuantity}
            onChange={(e) => setProductQuantity(e.target.value)}
            required
            min="0"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          />
        </div>
        <button
          type="submit"
          className="w-full bg-rose-950 text-white py-2 rounded-md hover:bg-pink-950 transition-colors"
        >
          Save Changes
        </button>
      </form>
    </div>
  );
}

export default EditProductForm;
