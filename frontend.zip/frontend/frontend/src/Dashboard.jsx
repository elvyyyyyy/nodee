import { Routes, Route, Navigate } from 'react-router-dom';
import AddProductForm from './AddProductForm';
import ProductsTable from './ProductsTable';
import EditProductForm from './EditProductForm';
import ImportProductForm from './ImportProductForm';
import ImportsTable from './ImportsTable';
import ExportProductForm from './ExportProductForm';
import ExportsTable from './ExportsTable';
import EditImportForm from './EditImportForm';
import EditExportForm from './EditExportForm';
import ProductsReport from './ProductsReport';





function Dashboard() {
  return (
    <div className="min-h-screen p-6">
      <Routes>
        <Route path="/" element={<Navigate to="home" replace />} />
        <Route path="home" element={<ProductsTable />} />
        <Route path="Addproducts" element={<AddProductForm />} />
        <Route path="edit/:productId" element={<EditProductForm />} />
        <Route path="import" element={<ImportProductForm/>} />
        <Route path="imports" element={<ImportsTable />} />
        <Route path="export" element={<ExportProductForm />} />
        <Route path="exports" element={<ExportsTable />} />
        <Route path="edit-import/:importId" element={<EditImportForm />} />
        <Route path="edit-export/:exportId" element={<EditExportForm />} />
        <Route path="report" element={<ProductsReport />} />



      </Routes>
    </div>
  );
}

export default Dashboard;
