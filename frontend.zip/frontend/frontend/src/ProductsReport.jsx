import { useState, useEffect } from 'react';
import axios from 'axios';

function ProductsReport() {
  const [imports, setImports] = useState([]);
  const [exportsData, setExportsData] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchData = async () => {
    try {
      const [importsRes, exportsRes, productsRes] = await Promise.all([
        axios.get('http://localhost:3000/imports'),
        axios.get('http://localhost:3000/exports'),
        axios.get('http://localhost:3000/products'),
      ]);
      setImports(importsRes.data);
      setExportsData(exportsRes.data);
      setProducts(productsRes.data);
      setLoading(false);
    } catch (err) {
      setError('Failed to fetch report data');
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  if (loading) {
    return <div className="min-h-screen p-6 flex justify-center items-center">Loading report...</div>;
  }

  if (error) {
    return <div className="min-h-screen p-6 flex justify-center items-center text-red-600">{error}</div>;
  }

  // Create a map of product name to product details
  const productMap = {};

  // Add products from products list
  products.forEach(product => {
    if (!productMap[product.pro_name]) {
      productMap[product.pro_name] = {
        name: product.pro_name,
        addedQuantity: product.pro_quantity,
        importedQuantity: 0,
        exportedQuantity: 0,
      };
    } else {
      productMap[product.pro_name].addedQuantity += product.pro_quantity;
    }
  });

  // Aggregate imported quantities by product name from imports data
  imports.forEach(imp => {
    if (!productMap[imp.pro_name]) {
      productMap[imp.pro_name] = {
        name: imp.pro_name,
        addedQuantity: 0,
        importedQuantity: imp.pro_quantity,
        exportedQuantity: 0,
      };
    } else {
      productMap[imp.pro_name].importedQuantity += imp.pro_quantity;
    }
  });

  // Aggregate exported quantities by product name from exports data
  exportsData.forEach(exp => {
    if (!productMap[exp.pro_name]) {
      productMap[exp.pro_name] = {
        name: exp.pro_name,
        addedQuantity: 0,
        importedQuantity: 0,
        exportedQuantity: exp.pro_quantity,
      };
    } else {
      productMap[exp.pro_name].exportedQuantity += exp.pro_quantity;
    }
  });

  // Convert map to array for rendering
  const reportData = Object.values(productMap);

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4 text-rose-950">Products Report</h2>
      <table className="min-w-full bg-white border border-gray-300 rounded">
        <thead>
          <tr>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">#</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">Product Name</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">Added Quantity</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">Imported Quantity</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">Exported Quantity</th>
          </tr>
        </thead>
        <tbody>
          {reportData.map((item, index) => (
            <tr key={index} className="hover:bg-gray-100 even:bg-rose-100">
              <td className="py-2 px-4 border-b border-gray-300">{index + 1}</td>
              <td className="py-2 px-4 border-b border-gray-300">{item.name}</td>
              <td className="py-2 px-4 border-b border-gray-300">{item.addedQuantity}</td>
              <td className="py-2 px-4 border-b border-gray-300">{item.importedQuantity}</td>
              <td className="py-2 px-4 border-b border-gray-300">{item.exportedQuantity}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ProductsReport;
