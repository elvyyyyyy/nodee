import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

function EditImportForm() {
  const { importId } = useParams();
  const navigate = useNavigate();

  const [products, setProducts] = useState([]);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [address, setAddress] = useState('');
  const [date, setDate] = useState('');
  const [proQuantity, setProQuantity] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get('http://localhost:3000/products');
        setProducts(response.data);
      } catch (error) {
        console.error('Failed to fetch products:', error);
      }
    };
    fetchProducts();
  }, []);

  useEffect(() => {
    const fetchImport = async () => {
      try {
        const response = await axios.get(`http://localhost:3000/imports/${importId}`);
        const imp = response.data;
        setSelectedProductId(imp.product_id.toString());
        setAddress(imp.address);
        setDate(imp.date);
        setProQuantity(imp.pro_quantity);
      } catch (error) {
        setMessage('Failed to fetch import data');
      }
    };
    fetchImport();
  }, [importId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedProductId || !address || !date || !proQuantity) {
      setMessage('Please fill all fields');
      return;
    }
    try {
      const selectedProduct = products.find(p => p.id === Number(selectedProductId));
      await axios.put(`http://localhost:3000/imports/${importId}`, {
        pro_name: selectedProduct ? selectedProduct.pro_name : '',
        product_id: Number(selectedProductId),
        address,
        date,
        pro_quantity: Number(proQuantity),
      });
      setMessage('Import updated successfully');
      navigate('/dashboard/imports');
    } catch (error) {
      setMessage('Failed to update import');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded shadow-md">
      <h2 className="text-2xl font-semibold mb-6 text-rose-950">Edit Import</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1 font-medium text-gray-900">Product</label>
          <select
            value={selectedProductId}
            onChange={(e) => setSelectedProductId(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          >
            <option value="">Select a product</option>
            {products.map((product) => (
              <option key={product.id} value={product.id}>
                {product.pro_name} (ID: {product.id})
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900">Destination Address</label>
          <input
            type="text"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          />
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900">Import Date</label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          />
        </div>
        <div>
          <label className="block mb-1 font-medium text-gray-900">Quantity</label>
          <input
            type="number"
            value={proQuantity}
            onChange={(e) => setProQuantity(e.target.value)}
            required
            min="1"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-950"
          />
        </div>
        <button
          type="submit"
          className="w-full bg-rose-950 text-white py-2 rounded-md hover:bg-pink-950 transition-colors"
        >
          Update Import
        </button>
      </form>
      {message && <p className="mt-4 text-center text-green-600">{message}</p>}
    </div>
  );
}

export default EditImportForm;
