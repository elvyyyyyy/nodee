import { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function ImportsTable() {
  const [imports, setImports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const fetchImports = async () => {
    try {
      const response = await axios.get('http://localhost:3000/imports');
      setImports(response.data);
      setLoading(false);
    } catch (err) {
      setError('Failed to fetch imports');
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchImports();
  }, []);

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:3000/imports/${id}`);
      setImports(imports.filter((imp) => imp.id !== id));
    } catch (err) {
      setError('Failed to delete import');
    }
  };

  const handleEdit = (id) => {
    navigate(`/dashboard/edit-import/${id}`);
  };

  if (loading) {
    return <div className="min-h-screen p-6 flex justify-center items-center">Loading imports...</div>;
  }

  if (error) {
    return <div className="min-h-screen p-6 flex justify-center items-center text-red-600">{error}</div>;
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4 text-rose-950">Imports</h2>
      <table className="min-w-full bg-white border border-gray-300 rounded">
        <thead>
          <tr>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">#</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">Product Name</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">Product Id</th>

            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">Destination Address</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">Import Date</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">Quantity</th>
            <th className="py-2 px-4 border-b border-gray-300 text-center bg-rose-950 text-white">Actions</th>
          </tr>
        </thead>
        <tbody>
          {imports.map((imp, index) => (
          <tr key={index} className="hover:bg-gray-100 even:bg-rose-100">
            <td className="py-2 px-4 border-b border-gray-300">{index + 1}</td>
            <td className="py-2 px-4 border-b border-gray-300">{imp.pro_name}</td>
            <td className="py-2 px-4 border-b border-gray-300">{imp.product_id}</td>
            <td className="py-2 px-4 border-b border-gray-300">{imp.address}</td>
            <td className="py-2 px-4 border-b border-gray-300">{imp.date}</td>
            <td className="py-2 px-4 border-b border-gray-300">{imp.pro_quantity}</td>
            <td className="py-2 px-4 border-b border-gray-300">
              <div className="flex space-x-2 items-center justify-center">
                <button
                  onClick={() => handleEdit(imp.id)}
                  className="bg-rose-950 text-white px-4 py-1 mr-5 rounded hover:bg-rose-600"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(imp.id)}
                  className="bg-red-800 text-white px-3 py-1 rounded hover:bg-red-600"
                >
                  Delete
                </button>
              </div>
            </td>
          </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ImportsTable;
