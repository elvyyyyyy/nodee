import { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import Login from './Login';
import Register from './Register';
import Dashboard from './Dashboard';
import './App.css';

function App() {
  const [user, setUser] = useState(null);

  return (
    <Router>
      <NavBar user={user} setUser={setUser} />
      <main className="flex-grow container mx-auto p-6 mt-5">
        <Routes>
          <Route path="/login" element={<Login setUser={setUser} />} />
          <Route path="/register" element={<Register setUser={setUser} />} />
          <Route path="/dashboard/*" element={<Dashboard />} />
          <Route path="/"/>

        </Routes>
      </main>
    </Router>
  );
}

function NavBar({ user, setUser }) {
  const navigate = useNavigate();
  const location = useLocation();
  const tabs = ['home', 'Add products', 'import', 'export','report'];

  // Determine active tab based on current path
  let activeTab = '';
  if (location.pathname.startsWith('/dashboard')) {
    const pathTab = location.pathname.split('/')[2];
    activeTab = pathTab ? pathTab.toLowerCase() : 'home';
  }

const handleLogout = () => {
  setUser(null);
  navigate('/');
};


  return (
    <nav className="fixed top-0 left-0 right-0 bg-rose-950 p-4 text-white z-50">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex space-x-4">
          {user &&
            tabs.map((tab) => (
              <Link
                key={tab}
                to={`/dashboard/${tab.replace(/\s+/g, '')}`}
                className={`capitalize px-3 py-1 rounded ${
                  activeTab === tab.replace(/\s+/g, '').toLowerCase()
                    ? 'bg-rose-50 text-black font-medium'
                    : ' text-white hover:bg-rose-50 hover:text-black'
                }`}
              >
                {tab}
              </Link>
            ))}
        </div>
        <div className="flex space-x-4">
          {!user ? (
            <>
              <Link to="/login" className="bg-white text-rose-950 px-3 py-1 rounded hover:bg-gray-200">
                Login
              </Link>
              <Link to="/register" className="bg-white text-rose-950 px-3 py-1 rounded hover:bg-gray-200">
                Register
              </Link>
            </>
          ) : (
            <button
              onClick={handleLogout}
              className="bg-rose-50 text-rose-950 px-3 py-1 rounded hover:bg-rose-100"
            >
              Logout
            </button>
          )}
        </div>
      </div>
    </nav>
  );
}

export default App;
