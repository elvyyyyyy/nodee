import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function AddProductForm() {
  const [productName, setProductName] = useState('');
  const [productOwner, setProductOwner] = useState('');
  const [productQuantity, setProductQuantity] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
    const response = await axios.post('http://localhost:3000/products/add', {
  pro_name: productName,
  pro_owner: productOwner,
  pro_quantity: Number(productQuantity),
}, { withCredentials: true });

      setMessage(response.data.message || 'Product added successfully');
      setProductName('');
      setProductOwner('');
      setProductQuantity('');
      navigate('/dashboard/home');
    } catch (error) {
      setMessage('Failed to add product');
    }
  };

  return (
    <div className='justify-center items-center'>

    <form onSubmit={handleSubmit} className="w-100 bg-white p-7 rounded shadow-md mt-5 ml-90">
      <h2 className="text-xl font-semibold mb-4 text-rose-950">Add Product</h2>
      <div className="mb-4">
        <label className="block mb-1 font-medium text-gray-700 text-left">Product Name</label>
        <input
          type="text"
          value={productName}
          onChange={(e) => setProductName(e.target.value)}
          required
          className="w-full border border-gray-300 rounded px-3 py-2"
        />
      </div>
      <div className="mb-4">
        <label className="block mb-1 font-medium text-gray-700 text-left">Product Owner</label>
        <input
          type="text"
          value={productOwner}
          onChange={(e) => setProductOwner(e.target.value)}
          required
          className="w-full border border-gray-300 rounded px-3 py-2"
        />
      </div>
      <div className="mb-4">
        <label className="block mb-1 font-medium text-gray-700 text-left">Product Quantity</label>
        <input
          type="number"
          value={productQuantity}
          onChange={(e) => setProductQuantity(e.target.value)}
          required
          min="0"
          className="w-full border border-gray-300 rounded px-3 py-2"
        />
      </div>
      <button
        type="submit"
        className="w-full bg-rose-950 text-white px-4 py-2 rounded hover:bg-pink-950 transition-colors"
      >
        Submit
      </button>
      {message && <p className="mt-4 text-green-600">{message}</p>}
    </form>
    </div>

  );
}

export default AddProductForm;
